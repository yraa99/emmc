# Signal Monitor Update — GPIO7/8/9

Paket ini menggabungkan firmware + GUI untuk realtime ISP/Signal Monitor.

## Perubahan utama

1. Paket `signal.status` diproses khusus oleh tab **ISP TEST** dan tidak ditulis ke **CONSOLE / LOG**.
2. Mapping realtime:
   - CMD = GPIO7
   - CLK = GPIO8
   - DAT0 = GPIO9
3. RP2040 mengirim snapshot realtime sekitar setiap 150 ms saat Signal Monitor aktif.
4. CLK monitor memakai PWM RP2040 agar frekuensi dapat berjalan terus tanpa memblokir USB.
5. Status pin mendukung `HIGH`, `LOW`, dan `TOGGLING`.
6. GUI memiliki pilihan frekuensi 1 kHz–4 MHz dan tombol START/STOP MONITOR.
7. Kode monitor tidak lagi memakai GPIO10/11/12.
8. CMake menambahkan `hardware_pwm`.
9. IDENTIFY debug/stage log dan timeout 15 detik tetap dipertahankan.
10. `ISPTestTab` menggunakan `addWidget` untuk widget grid/status, sehingga tidak terkena error `addLayout(... QWidget ...)`.

## Format realtime

Firmware mengirim paket JSON seperti:

```json
{"type":"signal.status","cmd":1,"clk":0,"dat0":1,"cmd_state":"HIGH","clk_state":"TOGGLING","dat0_state":"HIGH","frequency_hz":400000,"requested_frequency_hz":400000}
```

Paket ini sengaja tidak masuk Console/Log.

## Build firmware

Gunakan Pico SDK yang sudah dipakai project ini:

```powershell
cmake -S . -B build -G Ninja -Dpicotool_DIR="C:\pico\picotool-install\lib\cmake\picotool"
cmake --build build
```

## Catatan verifikasi

Syntax Python pada file GUI/core yang disentuh telah dicek dengan `py_compile`.
Build firmware penuh tidak dijalankan di environment pengemasan ini karena Pico SDK Windows pengguna (`C:\pico-sdk-master`) tidak tersedia di environment ini. Source dan CMake sudah disiapkan untuk build pada environment Pico SDK pengguna.
